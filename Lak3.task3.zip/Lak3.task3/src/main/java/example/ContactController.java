// ContactController.java
package example.controller;

import example.model.Contact;
import example.repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ContactController {

    @Autowired
    private ContactRepository contactRepository;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("contacts", contactRepository.findAll());
        return "index";
    }

    @GetMapping("/add")
    public String showAddForm(Contact contact) {
        return "add";
    }

    @PostMapping("/add")
    public String addContact(Contact contact) {
        contactRepository.save(contact);
        return "redirect:/";
    }

    
}
