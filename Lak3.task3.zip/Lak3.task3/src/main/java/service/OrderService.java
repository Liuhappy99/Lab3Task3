package com.liu.service;

import com.liu.entity.Order;

public interface OrderService {

    void add(Order order);

    void update(Order order);

    void delete(Integer id);

    Order selectById(Integer id);

}