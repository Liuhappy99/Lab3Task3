package java;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages= "java.dao")
public class TestSpringBoot {
    public static void main(String[] args) {
        SpringApplication.run(TestSpringBoot.class);
        Logger logger = LoggerFactory.getLogger(TestSpringBoot.class);

        logger.trace("trace信息...");
        logger.debug("debug信息...");
        logger.info("info信息...");
        logger.warn("warn信息...");
        logger.error("error信息...");
    }
}