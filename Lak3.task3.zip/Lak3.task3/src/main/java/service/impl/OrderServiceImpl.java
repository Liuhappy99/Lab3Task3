package com.liu.service.impl;

import com.liu.dao.OrderDao;
import com.liu.entity.Order;
import com.liu.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    @Override
    public void add(Order order) {
        orderDao.insert(order);
    }

    @Override
    public void update(Order order) {
        orderDao.updateByPrimaryKey(order);
    }

    @Override
    public void delete(Integer id) {
        orderDao.deleteByPrimaryKey(id);
    }

    @Override
    public Order selectById(Integer id) {
        return orderDao.selectByPrimaryKey(id);
    }
}